export default class Config {
    entries;
    constructor(settings) {
        this.entries = this._loadFromSettings(settings);
    }
    _loadFromSettings(settings) {
        const config = [];
        // Load app shortcuts from GSettings
        const shortcutsJson = settings.get_string("shortcuts") ?? "";
        if (shortcutsJson) {
            try {
                const shortcuts = JSON.parse(shortcutsJson);
                for (const shortcut of shortcuts) {
                    config.push({
                        act: "launch",
                        key: shortcut.key.toLowerCase(),
                        app: shortcut.app,
                    });
                    console.debug(`[GlaunchV2] Loaded shortcut: ${shortcut.key} -> ${shortcut.app}`);
                }
            }
            catch (error) {
                console.error(`[GlaunchV2] Error parsing shortcuts: ${error}`);
            }
        }
        // Add default window management keybindings
        // These can be made configurable in the settings UI later
        config.push({ act: "win_prev", key: "f4" });
        config.push({ act: "win_other", key: "f12" });
        config.push({ act: "win_delete", key: "f3" });
        config.push({ act: "win_center_mouse" });
        return config;
    }
}
