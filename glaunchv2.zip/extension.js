import Meta from "gi://Meta";
import * as Main from "resource:///org/gnome/shell/ui/main.js";
import { Extension } from "resource:///org/gnome/shell/extensions/extension.js";
import Config from "./config.js";
import Launcher from "./launcher.js";
export default class GlaunchV2 extends Extension {
    _config = null;
    _settings = null;
    _launcher = null;
    _signalHandlers = [];
    _settingsChangedId = null;
    enable() {
        this._settings = this.getSettings();
        this._config = new Config(this._settings);
        this._launcher = new Launcher(this._config, this._settings);
        this._signalHandlers.push(global.window_manager.connect("map", (_, win) => {
            this._launcher?.storeApp(win.get_meta_window());
        }));
        this._signalHandlers.push(global.window_manager.connect("destroy", (_, win) => {
            this._launcher?.deleteApp(win.get_meta_window());
        }));
        // Listen for settings changes to reload keybindings
        this._settingsChangedId = this._settings.connect("changed::shortcuts", () => {
            this._reloadShortcuts();
        });
    }
    _reloadShortcuts() {
        if (!this._settings)
            return;
        console.debug("[GlaunchV2] Settings changed, reloading shortcuts...");
        // Unbind all current keybindings
        this._config?.entries.forEach((bind) => {
            if (bind.key) {
                Main.wm.removeKeybinding(bind.key);
            }
        });
        // Reload config and launcher
        this._config = new Config(this._settings);
        this._launcher = new Launcher(this._config, this._settings);
        console.debug("[GlaunchV2] Shortcuts reloaded");
        // Refocus the Extensions preferences window
        this._focusExtensionsWindow();
    }
    _focusExtensionsWindow() {
        const windows = global.display.get_tab_list(Meta.TabList.NORMAL, null);
        for (const win of windows) {
            const wmClass = win.get_wm_class();
            // Match GNOME Extensions app or extension-prefs window
            if (wmClass && (wmClass.includes("Extensions") || wmClass.includes("extension-prefs"))) {
                win.raise_and_make_recent_on_workspace(win.get_workspace());
                win.focus(global.get_current_time());
                console.debug("[GlaunchV2] Refocused Extensions window");
                return;
            }
        }
    }
    disable() {
        this._signalHandlers.forEach(id => {
            global.window_manager.disconnect(id);
        });
        this._signalHandlers = [];
        // Disconnect settings change handler
        if (this._settingsChangedId !== null && this._settings) {
            this._settings.disconnect(this._settingsChangedId);
            this._settingsChangedId = null;
        }
        this._config?.entries.forEach((bind, _) => {
            if (bind.key) {
                Main.wm.removeKeybinding(bind.key);
            }
        });
        this._settings?.run_dispose();
        this._settings = null;
        this._config = null;
        this._launcher = null;
    }
}
